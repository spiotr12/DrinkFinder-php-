<?php
//localhost
//$db_host = "localhost";
//$db_username = "root";
//$db_password = "";
//$db_dbname = "drinker";

//hostinger
$db_host = "mysql.hostinger.co.uk";
$db_username = "u500179497_drink";
$db_password = "OmAS5xhae3Zm";
$db_dbname = "u500179497_df";

?>